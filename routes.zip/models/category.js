class Category {
    constructor(id, categoryName ) {
            this.id = id;
            this.categoryName = categoryName;
    }
}
module.exports = Category;