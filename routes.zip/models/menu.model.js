class Menu {
    constructor(name, image, description, price, size ) {
            this.name = name;      
            this.image = image;                   
            this.price = price;            
            this.size = size;
    }
}

module.exports = Menu;